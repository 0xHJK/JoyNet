<?php
    define('APP_NAME', 'Admin');
    define('APP_PATH', './Admin/');
    define('APP_DEBUG', TRUE);
    include './ThinkPHP/ThinkPHP.php';
?>