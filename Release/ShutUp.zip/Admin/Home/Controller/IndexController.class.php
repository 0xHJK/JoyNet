<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        if(!isset($_SESSION['username']) || $_SESSION['username'] == ''){
            $this->display("login");
        }elseif ($_SESSION['myzjut'] == 'HJK') {
            $this->display("admin");
        }
    }

    public function checkLogin(){
        $login["username"] = $_POST["username"];
        $login["pwd"] = $_POST["password"];
        $User = M("User")-> where($login) ->select();
        if($User && !$user['lock']){
            session("myzjut", "HJK");
            // $this->display("admin");
            $this->redirect("Home/index");
            // $data['status'] = 1;
            // $this -> ajaxReturn($data);
        }else{
            $this->error('登陆失败');
            // $data['status'] = 2;
            // $this -> ajaxReturn($data);
        }
    }

    public function hello(){
        echo "hi";
    }
}