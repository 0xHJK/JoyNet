<?php
$config = array();

return array_merge(include './Conf/config.php', $config);
?>