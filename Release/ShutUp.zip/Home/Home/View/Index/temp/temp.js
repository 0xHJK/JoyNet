$(function () {  
    //方式一 Ajax方式获取Json数据  
    $.ajax({  
        url: 'jsondata.ashx?type=1',  
        type: 'GET',  
        dataType: 'json',  
        timeout: 1000,  
        cache: false,  
        beforeSend: LoadFunction, //加载执行方法    
        error: erryFunction,  //错误执行方法    
        success: succFunction //成功执行方法    
    })  
    function LoadFunction() {  
        $("#list").html('加载中...');  
    }  
    function erryFunction() {  
        alert("error");  
    }  
    function succFunction(tt) {                  
        var json = eval(tt); //数组     
        var tt = "";  
        $.each(json, function (index) {  
            //循环获取数据    
            var Id = json[index].id;  
            var Name = json[index].name;  
            var Age = json[index].age;  
            var Score = json[index].score;  
            tt += Id + "___" + Name + "___" + Age + "___" + Score + "<br>";  
        });  
        $("#list").html('');  
        $("#list").html(tt);  
    })