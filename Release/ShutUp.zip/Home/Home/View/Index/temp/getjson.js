//获取全部事件
$.getJSON("http://210.32.200.91:8082/jh_www/api?APPID=APPID01&token=saf32e34ewsf8f42&model=Event&action=list",function(data){
 // $("#status").append(data.status+"<hr/>");
 // $("#content").append(data.data+"<hr/>");
 if (data.status==00) {
   var aEventTime;
   var aEventDay;
   $.each(data.data, function(i, item) {
     aEventTime=item.formatTime_etime.split(" ");
     aEventDay=aEventTime[0].split("-");
     // alert(aEventDay[2]);
     $("#event").append(
       "<li><div class='time'>" + 
       "<span class='year'>" + aEventDay[0] + "/" + aEventDay[1] + "</span>" + 
       "<span class='day'>" + aEventDay[2] + "</span>" +
       "<span class='event_round'></span>" +
       "</div><div class='eventList'>" +
       "<a href='#' class='title'>" + item.etitle + "</a>" +
       "<div class='content'>" + item.econtent + "</div>" +
       "</div></li>"
     );
   }); 
 } else {
   $("#event").append(
     "<li><div class='time'>" + 
     "<span class='year'>" + "2013" + "/" + "12" + "</span>" + 
     "<span class='day'>" + "24" + "</span>" +
     "<span class='event_round'></span>" +
     "</div><div class='eventList'>" +
     "<a href='#' class='title'>" + "哎呀~服务器出了一个问题" + "</a>" +
     "<div class='content'>" + "一大波技术人员正在路上……(´・ω・`)" + "</div>" +
     "</div></li>"
   );        
 }
});
//获取导航链接
$.getJSON("http://210.32.200.91:8082/jh_www/api?APPID=APPID01&token=saf32e34ewsf8f42&model=Navigator&action=list",function(data){
 if (data.status==00) {
   $.each(data.data, function(i, item) {  
     $("#nav").html("<a href=" + item.destination_url + "target='_blank'>" + item.naname + "</a>");  
   });
 } else {
   $("#nav").html(
     "<a href='http://bbs.zjut.edu.cn/'  target='_blank'>论坛</a>" +
     "<a href='http://feel.zjut.com/'  target='_blank'>电台</a>" +
     "<a href='http://doc.zjut.com/'  target='_blank'>文库</a>" +
     "<a href='http://go.zjut.com/'  target='_blank'>导航</a>" +
     "<a href='http://pt.zjut.com/'  target='_blank'>PT站</a>");
 }
});
获取新鲜事
$.getJSON("http://210.32.200.91:8082/jh_www/api?APPID=APPID01&token=saf32e34ewsf8f42&model=Notice&action=getNew",function(data){
 $.each(data.data, function(i, item) {  
   $("#notice").append("<a href=" + item.destination_url + "target='_blank'>" + item.ncontent + "</a>");  
 }); 
});