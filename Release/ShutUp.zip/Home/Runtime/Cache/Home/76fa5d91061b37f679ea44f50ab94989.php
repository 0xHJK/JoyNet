<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="/JoyNet/Public/css/layout.css">
	<link rel="stylesheet" href="/JoyNet/Public/css/style.css">
	<link rel="icon" href="/JoyNet/Public/img/favicon.ico" type="image/x-icon">
	<script type="text/javascript" src="/JoyNet/Public/js/jquery-1.11.0.min.js"></script>
	<script type="text/javascript" src="/JoyNet/Public/js/unslider.min.js"></script>
	<title>精弘网络</title>
	<script>
	$(function(){
		var listNavUrl = "http://localhost/JoyNet/index.php?m=Home&a=listNav";
		var listEveUrl = "http://localhost/JoyNet/index.php?m=Home&a=listEve";
		var showNotUrl = "http://localhost/JoyNet/index.php?m=Home&a=showNot";
		//获取全部导航
		$.ajax({
			url: listNavUrl,
			type: "GET",
			dataType: "json",
			timeout: 1000,
			cache: false,
			error: navErrorFunc,
			success: navListFunc
		});
		function navErrorFunc(){
			$("#navList").html(
				"<li class='navListItem'><a href='http://www.zjut.com/'  target='_blank'>首页</a></li>" +
				"<li class='navListItem'><a href='http://bbs.zjut.edu.cn/'  target='_blank'>论坛</a></li>" +
				"<li class='navListItem'><a href='http://hd.izjut.com/'  target='_blank'>圈圈</a></li>" +
				"<li class='navListItem'><a href='http://feel.zjut.com/'  target='_blank'>电台</a></li>" +
				"<li class='navListItem'><a href='http://pan.zjut.com/'  target='_blank'>网盘</a></li>" +
				"<li class='navListItem'><a href='http://news.zjut.com/'  target='_blank'>资讯</a></li>" +
				"<li class='navListItem'><a href='http://go.zjut.com/'  target='_blank'>导航</a></li>");
			navMouseOver();
			navBarWidth();
		}
		function navListFunc(data){
			console.log(data.content);
			$.each(data.content, function(i, item) {
				// alert(item.destination_url);
				$("#navList").append("<li class='navListItem'><a href='" + item.destination_url + "' target='_blank'>" + item.naname + "</a></li>");
			});
			navMouseOver();
			navBarWidth();
		}

		//获取新的通知
		$.ajax({
			url: showNotUrl,
			type: "GET",
			dataType: "json",
			timeout: 1000,
			cache: false,
			success: notListFunc
		});
		function notListFunc(data){
			console.log(data.content[0].ncontent);
			// $.each(data.data, function(i, item) {  
				$("#notice").html("<h2><a href='" + data.content[0].destination_url + "' target='_blank'>" + data.content[0].ncontent + "</a></h2>");
			// }); 
		}

		//获取全部事件
		$.ajax({
			url: listEveUrl,
			type: "GET",
			dataType: "json",
			timeout: 1000,
			cache: false,
			error: eventErrorFunc,
			success: eventListFunc
		});
		function eventErrorFunc(){
			$("#event").html(
				"<li><div class='time'><span class='year'>2014/09</span><span class='day'>13</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>2014级新生招新</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2014/07</span><span class='day'>07</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>精弘网络服务器转移</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2013/09</span><span class='day'>09</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>工大助手上线</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2013/01</span><span class='day'>01</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>荣获2013年浙江省文化传播创新十佳网站</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2012/05</span><span class='day'>05</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>精弘网络十周年庆</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2012/03</span><span class='day'>03</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>第一届精弘毅行</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2012/02</span><span class='day'>02</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>荣获第五届“全国高校百佳网站”荣誉称号</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2011/12</span><span class='day'>12</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>和香港环境保护协会协作举办水果贺卡2011活动，并荣获全国优秀团队奖</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2010/05</span><span class='day'>05</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>举办首届精弘商铺毕业生跳蚤市场</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2009/10</span><span class='day'>10</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>精弘商铺开始-shop.zjut.com</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2009/10</span><span class='day'>10</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>精弘商铺开始-shop.zjut.com</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2009/02</span><span class='day'>02</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>学工部站点竣工-www.xgb.zjut.edu.cn</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2008/12</span><span class='day'>12</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>个人空间升级至精弘家园（Ucenter Home）</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2008/09</span><span class='day'>09</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>精弘举办软件自由日系列活动，并成立开源社区-mosn.zjut.com</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2007/12</span><span class='day'>12</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>与校会合作直播TOP10</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2007/06</span><span class='day'>06</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>“新生论坛”升级</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2006/12</span><span class='day'>12</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>FEEL电台举办第一次真情祝福活动</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2006/05</span><span class='day'>05</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>第一版学生邮件开始-mail.zjut.com</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2005/05</span><span class='day'>05</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>精弘论坛两周年，管理团队录制《精弘论坛两周年视频》</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2005/02</span><span class='day'>02</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>公共FTP开始-ftp.zjut.com</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2004/12</span><span class='day'>12</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>Feel电台创立-radio.zjut.com</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2004/05</span><span class='day'>05</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>精弘博客开始-blog.zjut.com</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2003/12</span><span class='day'>12</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>新闻网开始-news.zjut.com</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2003/05</span><span class='day'>05</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>精弘论坛开始-bbs.zjut.com</a><div class='content'></div></div></li>" +
				"<li><div class='time'><span class='year'>2002/05</span><span class='day'>05</span><span class='event_round'></span></div><div class='eventList'><a href='#' class='title'>精弘苑网站诞生-www.zjut.com</a><div class='content'></div></div></li>"
			);
		}
		function eventListFunc (data) {
			$.each(data.content, function(i, item) {
				var arrTime = item.etime.split("-");
				$("#event").append(
					"<li id='test'><div class='time'>" + 
					"<span class='year'>" + arrTime[0] + "</span>" + 
					"<span class='day'>" + arrTime[1] + "</span>" +
					"<span class='event_round'></span>" +
					"</div><div class='eventList'>" +
					"<a href='#' class='title'>" + item.etitle + "</a>" +
					"<div class='content'>" + item.econtent + "</div>" +
					"</div></li>"
				);
			});
		}
		$('.banner').unslider();
	});

	//页面特效
	//导航鼠标移入
	function navMouseOver(){
		$(".navListItem").hover(function(){
			$("#navTag").stop();
			$("#navTag").animate({left:$(this).position().left},"high");
		});
	}
	//导航宽度适应
	function navBarWidth(){
		$("#nav").animate({width:$(".navListItem").length*130+1+'px'});
	}
	</script>
</head>
<body>
	<div class="box" id="header">
		<div class="header">
			<h1 class="logo" style="-webkit-animation: metro_grey 21s linear infinite;"></h1>
			<div id="nav" class="nav">
				<ul id="navList">
				</ul>
				<div id="navTag" class="navTag"></div>
			</div>
		</div>
	</div>
	<div class="box banner" id="slidebox">
    <ul>
        <li><img src="/JoyNet/Public/banner/slide1.jpg" alt=""></li>
        <li><img src="/JoyNet/Public/banner/slide2.jpg" alt=""></li>
        <li><img src="/JoyNet/Public/banner/slide3.jpg" alt=""></li>
        <li><img src="/JoyNet/Public/banner/slide4.jpg" alt=""></li>
        <li><img src="/JoyNet/Public/banner/slide5.jpg" alt=""></li>
    </ul>
    <div class="shadow" id="notice">
    	<h2><a href="#">精弘网络招新进行中</a></h2>
    </div>
	</div>
	<div class="box" id="intro">
		<div id="introContent" class="slide">
			<p><span style="font-size:40px">“精弘网络</span>是浙江工业大学校级学生组织，自2002年5月成立以来，以打造大学生五彩生活为宗旨，整合校内外网络传播资源，积极营造浓厚的网络文化氛围，为浙工大师生提供校内<i>网站导航、论坛、新闻资讯、Feel电台、下载站、开源社区、学生邮箱、即时通讯、linux更新源</i>等全方位服务，发展成为工大师生喜爱的学习资源中心、情感交流中心和生活交流中心。<span style="font-size:30px">”</span></p>
		</div>
		
	</div>
	<div class="box" id="timeline">
		<div class="inner">
			<div class="loading" style="display:none;"></div>
			<ul id="event" class="event">
			</ul>
		</div>
	</div>
	<div class="box" id="footer">
		<div class="share">
			<div class="thininner">
				<a href="http://www.izjut.com" class="icon"><img class="qrcode" src="/JoyNet/Public/img/weixin.png" alt="工大助手"></a>
				<a href="http://www.renren.com/jh1314" class="icon"><img class="qrcode" src="/JoyNet/Public/img/renren.png" alt=""></a>
				<a href="http://weibo.com/jhzjut" class="icon"><img class="qrcode" src="/JoyNet/Public/img/weibo.png" alt=""></a>
				<a href="https://github.com/ZJUT" class="icon"><img class="qrcode" src="/JoyNet/Public/img/github.png" alt="精弘网络GitHub"></a>
			</div>
		</div>
		<div class="copyright">
			<p>
				<span>友情链接：</span>
				<span><a href="http://www.moe.edu.cn/">中国教育部</a>&nbsp;|&nbsp;</span>
				<span><a href="http://www.univs.cn/">大学生在线</a>&nbsp;|&nbsp;</span>
				<span><a href="http://www.zjut.edu.cn/">浙江工业大学</a>&nbsp;|&nbsp;</span>
				<span><a href="http://www.lib.zjut.edu.cn/">浙工大图书馆</a>&nbsp;|&nbsp;</span>
				<span><a href="http://mail.zjut.edu.cn/">邮件系统</a></span>
			</p><br>
			<span>Copyright © 2014 <a href="http://www.zjut.com">浙江工业大学-精弘网络</a></span>&emsp;&emsp;
			<span>Developed by <a href="http://www.hjk.im">HJK</a> & <a href="http://westion.tk/">Westion</a> </span>
		</div>
	</div>
</body>
</html>