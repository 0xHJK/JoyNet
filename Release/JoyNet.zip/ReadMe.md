##需要修改的配置项

- [ Apache ] httpd.conf配置文件中加载了mod_rewrite.so模块 
- [ Apache ] AllowOverride None 将None改为 All 

- Index/Common/Conf/config.php里面的数据库配置
- Index/Home/View/index/index.html 里面的url（js开始处的三个）
- Index/Admin/View/index/admin.html 里面的url（js开始处的十二个）

- 数据库结构