<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="/JoyNet/Public/css/layout.css">
	<link rel="stylesheet" href="/JoyNet/Public/css/style.css">
	<link rel="icon" href="/JoyNet/Public/img/favicon.ico" type="image/x-icon">
	<script type="text/javascript" src="/JoyNet/Public/js/jquery-1.11.0.min.js"></script>
	<script type="text/javascript" src="/JoyNet/Public/js/get-index.js"></script>
	<script type="text/javascript" src="/JoyNet/Public/js/unslider.min.js"></script>
	<script type="text/javascript" src="/JoyNet/Public/js/animatescroll.min.js"></script>
	<title>精弘网络</title>
	<script>
	$(function(){
		var listNavUrl = "http://localhost/JoyNet/index.php?a=listNav";
		var listEveUrl = "http://localhost/JoyNet/index.php?a=listEve";
		var showNotUrl = "http://localhost/JoyNet/index.php?a=showNot";
		
		var p=0,t=0;
		$(window).scroll(function(e){
			p = $(this).scrollTop();
			if (t<=p) { //下滚时执行
				if ($(document).scrollTop()<($("#nav").offset().top - 200)){
					$("#nav").animatescroll({scrollSpeed:300,padding:50});
				} else if ($(document).scrollTop()>=($("#nav").offset().top) && $(document).scrollTop()<($("#intro").offset().top)-200){
					$("#intro").animatescroll({scrollSpeed:300,padding:-10});
				}
			} else { //上滚时执行
				if ($(document).scrollTop()>=($("#nav").offset().top) && $(document).scrollTop()<($("#intro").offset().top)){
					$("#nav").animatescroll({scrollSpeed:300,padding:50});
				} else if ($(document).scrollTop()<($("#nav").offset().top)-100){
					$("#header").animatescroll({scrollSpeed:300});
				}
			}
			setTimeout(function(){t = p;}, 0);
			// return false;
			// if ($(document).scrollTop()>($("#nav").offset().top - 50))
			// $(window).unbind();
		});
		$(document).scroll(function(){
			if($(document).scrollTop()>1200){
				$("#goTop").css("display","block").animate({
					bottom:"60px",
					opacity:0.5
				});
			} 
			if($(document).scrollTop()<1200) {
				$("#goTop").stop();
				$("#goTop").fadeOut("high");
			}
		});
		$("#logo").animate({
			opacity:1,
			height:"100vh"
		});
		$('.banner').unslider({
			fluid: true,  //响应式
			speed: 500,   //速度
			delay: 2500,  //延迟
			dots: true,   //点
		});

		getNav(listNavUrl);
		getEve(listEveUrl);
		getNotice(showNotUrl);
		$("#slidebox").mouseover(function(){
			$("#notice").stop();
			$("#notice").fadeIn();
		});
		$("#slidebox").mouseout(function(){
			$("#notice").stop();
			$("#notice").fadeOut();
		});
		$("#goTop").mouseover(function(){
			$("#goTop").animate({
				opacity:1
			});
		});
		$("#goTop").mouseout(function(){
			$("#goTop").animate({
				opacity:0.5
			});
		});
		$("#goTop").click(function(){
			$("#nav").animatescroll({scrollSpeed:300,padding:50});
			// $("#goTop").fadeOut();
		});
	});


	</script>
</head>
<body>
	<div class="box imax" id="header">
		<div class="header">
			<h1 class="logo" id="logo"></h1>
		</div>	
		<div id="nav" class="nav">
			<ul id="navList"></ul>
			<div id="navTag" class="navTag"></div>
		</div>
	</div>

	<div class="box banner" id="slidebox">
	    <ul>
	        <li><img src="/JoyNet/Public/banner/slide1.jpg" alt=""></li>
	        <li><img src="/JoyNet/Public/banner/slide2.jpg" alt=""></li>
	        <li><img src="/JoyNet/Public/banner/slide3.jpg" alt=""></li>
	        <li><img src="/JoyNet/Public/banner/slide4.jpg" alt=""></li>
	        <li><img src="/JoyNet/Public/banner/slide5.jpg" alt=""></li>
	    </ul>
	    <div class="shadow" id="notice" style="display:none;">
	    	<h2><a href="#">Hi 精弘！</a></h2>
	    </div>
	</div>

	<div class="box" id="intro">
		<div id="introContent" class="slide">
			<p><span style="font-size:40px">“精弘网络</span>是浙江工业大学校级学生组织，自2002年5月成立以来，以打造大学生五彩生活为宗旨，整合校内外网络传播资源，积极营造浓厚的网络文化氛围，为浙工大师生提供校内<i>网站导航、论坛、新闻资讯、Feel电台、下载站、开源社区、学生邮箱、即时通讯、linux更新源</i>等全方位服务，发展成为工大师生喜爱的学习资源中心、情感交流中心和生活交流中心。<span style="font-size:30px">”</span></p>
		</div>
	</div>


	<div class="box" id="timeline">
		<div class="inner">
			<div class="loading" style="display:none;"></div>
			<ul id="event" class="event">
			</ul>
		</div>
	</div>
	<div id="goTop" class="goTop"></div>
	<div class="box" id="footer">
		<div class="share">
			<div class="thininner">
				<a href="http://www.izjut.com" class="icon"><img class="qrcode" src="/JoyNet/Public/img/weixin.png" alt="工大助手"></a>
				<a href="http://www.renren.com/jh1314" class="icon"><img class="qrcode" src="/JoyNet/Public/img/renren.png" alt=""></a>
				<a href="http://weibo.com/jhzjut" class="icon"><img class="qrcode" src="/JoyNet/Public/img/weibo.png" alt=""></a>
				<a href="https://github.com/ZJUT" class="icon"><img class="qrcode" src="/JoyNet/Public/img/github.png" alt="精弘网络GitHub"></a>
			</div>
		</div>
		<div class="copyright">
			<p>
				<span>友情链接：</span>
				<span><a href="http://www.moe.edu.cn/">中国教育部</a>&nbsp;|&nbsp;</span>
				<span><a href="http://www.univs.cn/">大学生在线</a>&nbsp;|&nbsp;</span>
				<span><a href="http://www.zjut.edu.cn/">浙江工业大学</a>&nbsp;|&nbsp;</span>
				<span><a href="http://www.lib.zjut.edu.cn/">浙工大图书馆</a>&nbsp;|&nbsp;</span>
				<span><a href="http://mail.zjut.edu.cn/">邮件系统</a></span>
			</p><br>
			<span>Copyright © 2014 <a href="http://www.zjut.com">浙江工业大学-精弘网络</a></span>&emsp;&emsp;
			<span>Developed by <a href="http://www.hjk.im">HJK</a></span>
		</div>
	</div>
</body>
</html>