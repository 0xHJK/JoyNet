<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>精弘网络-登陆</title>
  <link rel="stylesheet" type="text/css" href="/JoyNet/Public/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="/JoyNet/Public/css/flat-ui.css">
  <link rel="stylesheet" type="text/css" href="/JoyNet/Public/css/demo.css">
  <script type="text/javascript" src="/JoyNet/Public/js/jquery-1.11.0.min.js"></script>
  <style type="text/css">

  </style>
  <script type="text/javascript">

  </script>
</head>
<body>
<div class="container">
  <div class="login">
    <div class="login-screen">
      <div class="login-icon">
        <img src="/JoyNet/Public/img/icon.png" alt="精弘网络">
        <h4></h4>
      </div>

      <div class="login-form">
        <form action="<?php echo U('checkLogin');?>" method="post">
          <div class="form-group">
            <input type="text" class="form-control login-field" name="username" value="" placeholder="用户名" id="login-name">
          </div>
          <div class="form-group">
            <input type="password" class="form-control login-field" name="password" value="" placeholder="密码" id="login-pass">
          </div>
          <input type="submit" id="loginBtn" class="btn btn-primary btn-lg btn-block" value="登陆">
          <p id="error" style="color:red;display:none;font-size:14px">用户名或密码错误</p>
          <!-- <a class="login-link" href="#">忘记密码?</a> -->
        </form>
      </div>
    </div>
  </div>
</div>
<div class="vimiumReset vimiumHUD" style="right: 150px; opacity: 0; display: none;"></div>
</body>
</html>