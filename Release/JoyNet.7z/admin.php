<?php
    define('BIND_MODULE','Admin');
    // define('BIND_CONTROLLER','Index');
    define('APP_NAME', 'Index');
    define('APP_PATH', './Index/');
    define('APP_DEBUG', TRUE);
    include './ThinkPHP/ThinkPHP.php';
?>