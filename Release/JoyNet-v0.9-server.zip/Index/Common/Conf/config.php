<?php
return array(
    //'配置项'=>'配置值'
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_USER' => 'root',
    'DB_PWD' => 'ambulong',
    'DB_NAME' => 'new_www',
    'DB_PREFIX' => 'jh_'
);
?>